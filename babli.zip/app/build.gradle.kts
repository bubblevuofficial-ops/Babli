plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.babli.assistant"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.babli.assistant"
        minSdk = 26
        targetSdk = 34
        versionCode = 2
        versionName = "2.0"
    }
    signingConfigs {
        create("saif") {
            storeFile = file("saif.p12")
            storePassword = "saifbabli"
            keyAlias = "saif"
            keyPassword = "saifbabli"
            storeType = "pkcs12"
        }
    }
    buildTypes {
        getByName("debug") {
            signingConfig = signingConfigs.getByName("saif")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}
