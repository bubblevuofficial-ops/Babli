package com.babli.assistant

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

class Prefs(ctx: Context) {
    private val sp = ctx.getSharedPreferences("saif_babli", Context.MODE_PRIVATE)

    var apiKey: String
        get() = sp.getString("key", "") ?: ""
        set(v) { sp.edit().putString("key", v.trim()).apply() }

    var model: String
        get() = sp.getString("model", "gemini-flash-latest") ?: "gemini-flash-latest"
        set(v) { sp.edit().putString("model", v.trim()).apply() }

    var userName: String
        get() = sp.getString("name", "Saif") ?: "Saif"
        set(v) { sp.edit().putString("name", v.trim()).apply() }

    var countryCode: String
        get() = sp.getString("cc", "92") ?: "92"
        set(v) { sp.edit().putString("cc", v.trim()).apply() }

    var speak: Boolean
        get() = sp.getBoolean("speak", true)
        set(v) { sp.edit().putBoolean("speak", v).apply() }

    var sensitivity: Int
        get() = sp.getInt("sens", 3)
        set(v) { sp.edit().putInt("sens", v).apply() }

    var profile: String?
        get() = sp.getString("profile", null)
        set(v) { sp.edit().putString("profile", v).apply() }

    private fun secretKey(): SecretKey {
        val ks = KeyStore.getInstance("AndroidKeyStore")
        ks.load(null)
        val existing = ks.getKey("babli_pin", null)
        if (existing is SecretKey) return existing
        val kg = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        kg.init(
            KeyGenParameterSpec.Builder(
                "babli_pin",
                KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
            )
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .build()
        )
        return kg.generateKey()
    }

    fun hasPin(): Boolean = sp.getString("pin", null) != null

    fun savePin(pin: String) {
        val c = Cipher.getInstance("AES/GCM/NoPadding")
        c.init(Cipher.ENCRYPT_MODE, secretKey())
        val ct = c.doFinal(pin.toByteArray())
        val s = Base64.encodeToString(c.iv, Base64.NO_WRAP) + ":" + Base64.encodeToString(ct, Base64.NO_WRAP)
        sp.edit().putString("pin", s).apply()
    }

    fun loadPin(): String? {
        val s = sp.getString("pin", null) ?: return null
        return try {
            val parts = s.split(":")
            val c = Cipher.getInstance("AES/GCM/NoPadding")
            c.init(Cipher.DECRYPT_MODE, secretKey(), GCMParameterSpec(128, Base64.decode(parts[0], Base64.NO_WRAP)))
            String(c.doFinal(Base64.decode(parts[1], Base64.NO_WRAP)))
        } catch (e: Exception) {
            null
        }
    }
}
