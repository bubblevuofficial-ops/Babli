package com.babli.assistant

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(48, 48, 48, 48)
        }
        val title = TextView(this).apply {
            text = "ببلی اسسٹنٹ\n\nبولیں: \"ببلی واٹس ایپ کھولو\""
            textSize = 20f
            gravity = Gravity.CENTER
        }
        root.addView(title)

        fun addButton(label: String, action: () -> Unit) {
            val b = Button(this)
            b.text = label
            b.setOnClickListener { action() }
            root.addView(b)
        }

        addButton("1) مائیک اور نوٹیفکیشن کی اجازت") {
            val perms = mutableListOf(Manifest.permission.RECORD_AUDIO)
            if (Build.VERSION.SDK_INT >= 33) perms.add(Manifest.permission.POST_NOTIFICATIONS)
            requestPermissions(perms.toTypedArray(), 1)
        }
        addButton("2) دوسری ایپس کے اوپر دکھانے کی اجازت") {
            startActivity(
                Intent(
                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:$packageName")
                )
            )
        }
        addButton("3) ببلی شروع کریں") {
            val i = Intent(this, VoiceService::class.java)
            startForegroundService(i)
        }
        addButton("ببلی بند کریں") {
            stopService(Intent(this, VoiceService::class.java))
        }
        addButton("4) بیٹری سیٹنگ کھولیں (Unrestricted کریں)") {
            startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
        }

        setContentView(root)
    }
}
