package com.babli.assistant

import android.content.Context
import android.content.Intent
import android.provider.ContactsContract

object Apps {
    data class A(val label: String, val pkg: String)

    fun list(ctx: Context): List<A> {
        val pm = ctx.packageManager
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return pm.queryIntentActivities(i, 0)
            .map { A(it.loadLabel(pm).toString(), it.activityInfo.packageName) }
            .distinctBy { it.pkg }
            .sortedBy { it.label.lowercase() }
    }

    /** آواز کا ڈھانچہ: اردو، ہندی اور انگلش ناموں کو ایک جیسے حروف میں بدلتا ہے (واٹس ایپ = whatsapp = tsp) */
    fun skel(s: String): String {
        val sb = StringBuilder()
        for (ch in s.lowercase()) {
            val m: Char? = when (ch) {
                'b', 'ب', 'ब', 'भ' -> 'b'
                'p', 'پ', 'प' -> 'p'
                't', 'ت', 'ٹ', 'ط', 'ट', 'त', 'थ', 'ठ' -> 't'
                's', 'z', 'ث', 'س', 'ص', 'ش', 'ض', 'ظ', 'ذ', 'ز', 'ژ', 'स', 'श', 'ष' -> 's'
                'c', 'k', 'q', 'x', 'ک', 'ق', 'چ', 'خ', 'क', 'ख', 'च', 'छ' -> 'k'
                'j', 'ج', 'ज', 'झ' -> 'j'
                'g', 'گ', 'غ', 'ग', 'घ' -> 'g'
                'd', 'د', 'ڈ', 'द', 'ध', 'ड', 'ढ' -> 'd'
                'r', 'ر', 'ڑ', 'र' -> 'r'
                'f', 'ف', 'फ' -> 'f'
                'l', 'ل', 'ल' -> 'l'
                'm', 'م', 'म' -> 'm'
                'n', 'ن', 'ں', 'न', 'ण' -> 'n'
                else -> null
            }
            if (m != null && (sb.isEmpty() || sb[sb.length - 1] != m)) sb.append(m)
        }
        return sb.toString()
    }

    fun lev(a: String, b: String): Int {
        val dp = Array(a.length + 1) { IntArray(b.length + 1) }
        for (i in 0..a.length) dp[i][0] = i
        for (j in 0..b.length) dp[0][j] = j
        for (i in 1..a.length) for (j in 1..b.length) {
            val cost = if (a[i - 1] == b[j - 1]) 0 else 1
            dp[i][j] = minOf(dp[i - 1][j] + 1, dp[i][j - 1] + 1, dp[i - 1][j - 1] + cost)
        }
        return dp[a.length][b.length]
    }

    fun find(ctx: Context, query: String): A? {
        val apps = list(ctx)
        val q = query.trim().lowercase()
        if (q.isEmpty()) return null
        apps.firstOrNull { it.label.lowercase() == q }?.let { return it }
        apps.firstOrNull { it.label.lowercase().contains(q) }?.let { return it }
        val qs = skel(q)
        if (qs.length < 2) return null
        var best: A? = null
        var bestScore = 99
        for (a in apps) {
            val ls = skel(a.label)
            if (ls.length < 2) continue
            val d = lev(qs, ls)
            val sc = when {
                d == 0 -> 0
                maxOf(qs.length, ls.length) >= 4 && d <= 1 -> 1
                qs.length >= 3 && ls.contains(qs) -> 2
                ls.length >= 3 && qs.contains(ls) -> 2
                else -> 99
            }
            if (sc < bestScore) {
                best = a
                bestScore = sc
            }
        }
        return best
    }

    /** (نام, نمبر) */
    fun contact(ctx: Context, query: String): Pair<String, String>? {
        val digits = query.filter { it.isDigit() || it == '+' }
        if (digits.count { it.isDigit() } >= 6) return Pair(query, digits)
        val q = query.trim().lowercase()
        if (q.isEmpty()) return null
        val qs = skel(q)
        var best: Pair<String, String>? = null
        var bestSc = 99
        val c = ctx.contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(
                ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                ContactsContract.CommonDataKinds.Phone.NUMBER
            ),
            null, null, null
        ) ?: return null
        c.use {
            while (it.moveToNext()) {
                val name = it.getString(0) ?: continue
                val num = it.getString(1) ?: continue
                val n = name.lowercase()
                val sn = skel(n)
                val sc = when {
                    n == q -> 0
                    n.length >= 2 && (n.contains(q) || q.contains(n)) -> 1
                    qs.length >= 2 && sn == qs -> 2
                    qs.length >= 3 && sn.isNotEmpty() && lev(sn, qs) <= 1 -> 3
                    else -> 99
                }
                if (sc < bestSc) {
                    best = Pair(name, num)
                    bestSc = sc
                }
            }
        }
        return best
    }
}
