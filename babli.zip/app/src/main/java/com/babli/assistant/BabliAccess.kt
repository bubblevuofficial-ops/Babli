package com.babli.assistant

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Path
import android.graphics.Rect
import android.os.Bundle
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class BabliAccess : AccessibilityService() {

    companion object {
        @Volatile var inst: BabliAccess? = null
    }

    override fun onServiceConnected() {
        inst = this
        BabliState.add("✅ Accessibility چالو ہو گئی")
    }

    override fun onUnbind(intent: Intent?): Boolean {
        inst = null
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        inst = null
        super.onDestroy()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    fun global(action: Int): Boolean = performGlobalAction(action)

    private fun roots(): List<AccessibilityNodeInfo> {
        val l = ArrayList<AccessibilityNodeInfo>()
        try {
            val ws = windows
            if (ws != null) for (w in ws) {
                val r = w.root
                if (r != null) l.add(r)
            }
        } catch (e: Exception) {
        }
        if (l.isEmpty()) {
            val r = rootInActiveWindow
            if (r != null) l.add(r)
        }
        return l
    }

    private fun walk(n: AccessibilityNodeInfo?, depth: Int, fn: (AccessibilityNodeInfo) -> Unit) {
        if (n == null || depth > 40) return
        fn(n)
        for (i in 0 until n.childCount) walk(n.getChild(i), depth + 1, fn)
    }

    private fun clickNode(n: AccessibilityNodeInfo?): Boolean {
        var c = n
        var depth = 0
        while (c != null && depth < 7) {
            if (c.isClickable && c.isEnabled) return c.performAction(AccessibilityNodeInfo.ACTION_CLICK)
            c = c.parent
            depth++
        }
        return false
    }

    fun swipe(x1: Float, y1: Float, x2: Float, y2: Float, ms: Long) {
        val p = Path()
        p.moveTo(x1, y1)
        p.lineTo(x2, y2)
        val g = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(p, 0, ms)).build()
        dispatchGesture(g, null, null)
    }

    fun tapAt(x: Float, y: Float) {
        val p = Path()
        p.moveTo(x, y)
        val g = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(p, 0, 60)).build()
        dispatchGesture(g, null, null)
    }

    fun scroll(dir: String) {
        val dm = resources.displayMetrics
        val w = dm.widthPixels.toFloat()
        val h = dm.heightPixels.toFloat()
        when (dir) {
            "down" -> swipe(w / 2, h * 0.72f, w / 2, h * 0.28f, 350)
            "up" -> swipe(w / 2, h * 0.28f, w / 2, h * 0.72f, 350)
            "left" -> swipe(w * 0.2f, h / 2, w * 0.8f, h / 2, 350)
            "right" -> swipe(w * 0.8f, h / 2, w * 0.2f, h / 2, 350)
        }
    }

    fun clickText(t: String): Boolean {
        for (r in roots()) {
            val l = r.findAccessibilityNodeInfosByText(t) ?: continue
            for (n in l) if (clickNode(n)) return true
        }
        return false
    }

    fun clickId(id: String): Boolean {
        for (r in roots()) {
            val l = r.findAccessibilityNodeInfosByViewId(id) ?: continue
            for (n in l) if (clickNode(n)) return true
        }
        return false
    }

    private fun clickExact(t: String): Boolean {
        for (r in roots()) {
            val found = ArrayList<AccessibilityNodeInfo>()
            walk(r, 0) { n ->
                val tx = n.text?.toString()
                val cd = n.contentDescription?.toString()
                if (tx == t || cd == t) found.add(n)
            }
            for (n in found) if (clickNode(n)) return true
        }
        return false
    }

    fun typeText(t: String): Boolean {
        for (r in roots()) {
            var target: AccessibilityNodeInfo? = r.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
            if (target == null) {
                walk(r, 0) { n -> if (target == null && n.isEditable) target = n }
            }
            val tg = target
            if (tg != null) {
                val b = Bundle()
                b.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, t)
                return tg.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, b)
            }
        }
        return false
    }

    /** پہلا سوئچ (وائی فائی/بلوٹوتھ پینل میں) مطلوبہ حالت میں کرتا ہے */
    fun setSwitch(on: Boolean): Boolean {
        for (r in roots()) {
            var sw: AccessibilityNodeInfo? = null
            walk(r, 0) { n ->
                if (sw == null && n.isCheckable) sw = n
            }
            val s = sw
            if (s != null) {
                if (s.isChecked == on) return true
                return clickNode(s)
            }
        }
        return false
    }

    fun playFirstVideo(): Boolean {
        val dm = resources.displayMetrics
        val h = dm.heightPixels
        var best: AccessibilityNodeInfo? = null
        var bestTop = Int.MAX_VALUE
        val rect = Rect()
        for (r in roots()) {
            walk(r, 0) { n ->
                val cd = n.contentDescription?.toString() ?: ""
                if (cd.length > 25 && n.isClickable) {
                    n.getBoundsInScreen(rect)
                    if (rect.top > h * 0.15 && rect.top < bestTop) {
                        best = n
                        bestTop = rect.top
                    }
                }
            }
        }
        val b = best
        if (b != null) return b.performAction(AccessibilityNodeInfo.ACTION_CLICK)
        tapAt(dm.widthPixels / 2f, h * 0.33f)
        return true
    }

    /** لاک اسکرین پر اوپر سوائپ کر کے پن کے نمبر دباتا ہے (پس منظر کے تھریڈ سے بلائیں) */
    fun unlockWithPin(pin: String): Boolean {
        val dm = resources.displayMetrics
        swipe(dm.widthPixels / 2f, dm.heightPixels * 0.85f, dm.widthPixels / 2f, dm.heightPixels * 0.25f, 350)
        Thread.sleep(900)
        for (ch in pin) {
            if (!clickExact(ch.toString())) return false
            Thread.sleep(160)
        }
        Thread.sleep(250)
        for (name in listOf("Enter", "ENTER", "enter", "OK", "Ok")) {
            if (clickExact(name)) break
        }
        return true
    }
}
