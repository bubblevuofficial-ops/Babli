package com.babli.assistant

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.Shader
import android.view.View
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

class OrbView(ctx: Context) : View(ctx) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private var t = 0f
    private var smooth = 0f

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val cx = w / 2
        val cy = h / 2
        val base = min(w, h) * 0.20f
        val mode = BabliState.mode
        val lvl = if (mode == "thinking") 0.35f + 0.25f * sin(t * 4) else BabliState.level
        smooth += (lvl - smooth) * 0.25f
        t += 0.05f
        val col = when (mode) {
            "thinking" -> 0xFFB388FF.toInt()
            "speaking" -> 0xFF00E5FF.toInt()
            "listening" -> 0xFF448AFF.toInt()
            else -> 0xFF607D8B.toInt()
        }
        val r = base * (1f + 0.30f * smooth + 0.03f * sin(t))
        val rgb = col and 0x00FFFFFF

        // چمک
        p.style = Paint.Style.FILL
        p.shader = RadialGradient(cx, cy, r * 2.4f, intArrayOf(rgb or (0x80 shl 24), rgb or (0x00 shl 24)), null, Shader.TileMode.CLAMP)
        c.drawCircle(cx, cy, r * 2.4f, p)

        // مرکز
        p.shader = RadialGradient(cx - r * 0.3f, cy - r * 0.3f, r * 1.3f, intArrayOf(0xFFFFFFFF.toInt(), col, rgb or (0xFF shl 24)), floatArrayOf(0f, 0.45f, 1f), Shader.TileMode.CLAMP)
        c.drawCircle(cx, cy, r, p)

        // لہریں
        p.shader = null
        p.style = Paint.Style.STROKE
        p.strokeCap = Paint.Cap.ROUND
        p.strokeWidth = base * 0.06f
        p.color = col
        val bars = 56
        for (i in 0 until bars) {
            val ang = 2.0 * PI * i / bars
            val wave = 0.5f + 0.5f * sin(t * 3 + i * 0.6f)
            val amp = 0.12f + 0.88f * smooth * wave
            val inner = r * 1.22f
            val outer = inner + base * 0.9f * amp
            c.drawLine(
                cx + inner * cos(ang).toFloat(), cy + inner * sin(ang).toFloat(),
                cx + outer * cos(ang).toFloat(), cy + outer * sin(ang).toFloat(), p
            )
        }
        postInvalidateOnAnimation()
    }
}
