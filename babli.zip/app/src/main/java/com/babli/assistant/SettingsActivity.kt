package com.babli.assistant

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast

class SettingsActivity : Activity() {
    private lateinit var prefs: Prefs
    private lateinit var box: LinearLayout
    private lateinit var permStatus: TextView
    private lateinit var voiceStatus: TextView
    private lateinit var key: EditText
    private lateinit var model: EditText
    private lateinit var name: EditText
    private lateinit var cc: EditText
    private lateinit var pin: EditText
    private lateinit var speak: CheckBox
    private lateinit var sens: SeekBar
    private lateinit var sensLabel: TextView

    private val sentences = listOf(
        "ببلی، واٹس ایپ کھولو",
        "ببلی، میرے لیے یوٹیوب پر گانا لگاؤ",
        "ببلی، فون کو لاک کر دو",
        "ببلی، آج موسم کیسا ہے",
        "ببلی، کال کاٹ دو",
        "ببلی، اسکرول نیچے کرو"
    )

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun title(t: String) {
        val v = TextView(this)
        v.text = t
        v.setTextColor(Color.parseColor("#80D8FF"))
        v.textSize = 17f
        v.setPadding(0, dp(22), 0, dp(6))
        box.addView(v)
    }

    private fun note(t: String): TextView {
        val v = TextView(this)
        v.text = t
        v.setTextColor(Color.parseColor("#B0BEC5"))
        v.textSize = 13f
        v.setPadding(0, dp(2), 0, dp(4))
        box.addView(v)
        return v
    }

    private fun btn(t: String, f: () -> Unit) {
        val b = Button(this)
        b.text = t
        b.setOnClickListener { f() }
        box.addView(b, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
    }

    private fun field(hint: String, type: Int, value: String = ""): EditText {
        val e = EditText(this)
        e.hint = hint
        e.setText(value)
        e.inputType = type
        e.setTextColor(Color.WHITE)
        e.setHintTextColor(Color.parseColor("#78909C"))
        box.addView(e, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        return e
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = Prefs(this)
        val bg = Color.parseColor("#05060F")
        window.statusBarColor = bg
        window.navigationBarColor = bg

        val sc = ScrollView(this)
        sc.setBackgroundColor(bg)
        box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(16), dp(24), dp(16), dp(40))
        sc.addView(box)

        val head = TextView(this)
        head.text = "⚙️ سیٹنگز"
        head.setTextColor(Color.WHITE)
        head.textSize = 22f
        head.gravity = Gravity.CENTER
        box.addView(head)

        title("1) اجازتیں (ترتیب سے)")
        permStatus = note("")
        btn("① مائیک، کال، SMS، کانٹیکٹ کی اجازت") {
            val l = mutableListOf(
                Manifest.permission.RECORD_AUDIO, Manifest.permission.CALL_PHONE,
                Manifest.permission.READ_CONTACTS, Manifest.permission.SEND_SMS,
                Manifest.permission.ANSWER_PHONE_CALLS
            )
            if (Build.VERSION.SDK_INT >= 33) l.add(Manifest.permission.POST_NOTIFICATIONS)
            requestPermissions(l.toTypedArray(), 1)
        }
        btn("② دوسری ایپس کے اوپر دکھانے کی اجازت") {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }
        btn("③ ایپ کی معلومات کھولیں (⋮ > Allow restricted settings)") {
            startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
        }
        btn("④ Accessibility کھولیں (سیف کی ببلی کو آن کریں)") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        btn("⑤ بیٹری: Unrestricted کریں") {
            startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
        }

        title("2) دماغ (Gemini)")
        note("aistudio.google.com سے مفت key بنا کر یہاں پیسٹ کریں۔ کسی کو بھیجیں نہیں۔")
        key = field(if (prefs.apiKey.isNotEmpty()) "key محفوظ ہے ✓ (بدلنے کے لیے نئی ڈالیں)" else "Gemini API key",
            InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD)
        model = field("ماڈل کا نام", InputType.TYPE_CLASS_TEXT, prefs.model)

        title("3) آپ کے بارے میں")
        name = field("آپ کا نام (ببلی اسی نام سے بلائے گی)", InputType.TYPE_CLASS_TEXT, prefs.userName)
        cc = field("ملک کا کوڈ (پاکستان 92، انڈیا 91)", InputType.TYPE_CLASS_PHONE, prefs.countryCode)

        title("4) اسکرین کا پن")
        note("پن فون میں انکرپٹ ہو کر محفوظ ہوتا ہے۔ نیا پن ڈال کر Save دبائیں تو پرانا بدل جاتا ہے۔")
        pin = field(if (prefs.hasPin()) "پن محفوظ ہے ✓ (بدلنے کے لیے نیا ڈالیں)" else "اسکرین لاک کا پن",
            InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD)

        title("5) بولنا")
        speak = CheckBox(this)
        speak.text = "ببلی جواب بول کر دے"
        speak.setTextColor(Color.WHITE)
        speak.isChecked = prefs.speak
        box.addView(speak)

        title("6) صرف میری آواز")
        voiceStatus = note(if (prefs.profile != null) "✓ آپ کی آواز رجسٹر ہے" else "ابھی آواز رجسٹر نہیں۔ بغیر رجسٹر کے ببلی ہر آواز سنے گی اور لاک نہیں کھولے گی۔")
        btn("🎤 اپنی آواز رجسٹر کریں (6 جملے)") { enroll() }
        btn("🧪 آواز ٹیسٹ کریں (3 سیکنڈ)") { testVoice() }
        sensLabel = note("")
        sens = SeekBar(this)
        sens.max = 4
        sens.progress = prefs.sensitivity - 1
        sens.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) { updateSens() }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        box.addView(sens)
        updateSens()

        title("")
        btn("💾 محفوظ کریں") { save() }

        setContentView(sc)
    }

    private fun updateSens() {
        val v = sens.progress + 1
        val t = when (v) {
            1 -> "بہت سخت"
            2 -> "سخت"
            3 -> "درمیانہ"
            4 -> "نرم"
            else -> "بہت نرم"
        }
        sensLabel.text = "آواز کی جانچ: $t (آپ کی آواز رد ہو تو نرم کریں، دوسرے کی چل جائے تو سخت کریں)"
    }

    override fun onResume() {
        super.onResume()
        refreshPerms()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        refreshPerms()
    }

    private fun has(p: String) = checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED

    private fun refreshPerms() {
        fun m(ok: Boolean) = if (ok) "✅" else "❌"
        val pm = getSystemService(PowerManager::class.java)
        permStatus.text = listOf(
            "${m(has(Manifest.permission.RECORD_AUDIO))} مائیک",
            "${m(has(Manifest.permission.CALL_PHONE) && has(Manifest.permission.ANSWER_PHONE_CALLS))} کال",
            "${m(has(Manifest.permission.READ_CONTACTS))} کانٹیکٹ",
            "${m(has(Manifest.permission.SEND_SMS))} SMS",
            "${m(Settings.canDrawOverlays(this))} اوپر دکھانا",
            "${m(BabliAccess.inst != null)} Accessibility",
            "${m(pm.isIgnoringBatteryOptimizations(packageName))} بیٹری"
        ).joinToString("   ")
    }

    private fun save() {
        if (key.text.isNotBlank()) prefs.apiKey = key.text.toString()
        if (model.text.isNotBlank()) prefs.model = model.text.toString()
        if (name.text.isNotBlank()) prefs.userName = name.text.toString()
        if (cc.text.isNotBlank()) prefs.countryCode = cc.text.toString().filter { it.isDigit() }
        val p = pin.text.toString().trim()
        if (p.isNotEmpty()) {
            if (p.all { it.isDigit() } && p.length >= 4) {
                prefs.savePin(p)
                pin.setText("")
                pin.hint = "پن محفوظ ہے ✓ (بدلنے کے لیے نیا ڈالیں)"
            } else {
                Toast.makeText(this, "پن صرف نمبروں کا اور کم از کم 4 ہندسے ہو", Toast.LENGTH_LONG).show()
                return
            }
        }
        key.setText("")
        key.hint = if (prefs.apiKey.isNotEmpty()) "key محفوظ ہے ✓ (بدلنے کے لیے نئی ڈالیں)" else "Gemini API key"
        prefs.speak = speak.isChecked
        prefs.sensitivity = sens.progress + 1
        Toast.makeText(this, "محفوظ ہو گیا ✓", Toast.LENGTH_SHORT).show()
    }

    private fun enroll() {
        if (!has(Manifest.permission.RECORD_AUDIO)) {
            Toast.makeText(this, "پہلے مائیک کی اجازت دیں", Toast.LENGTH_LONG).show()
            return
        }
        val wasRunning = BabliState.running
        stopService(Intent(this, BabliService::class.java))
        voiceStatus.text = "تیار ہو جائیں..."
        Thread {
            Thread.sleep(800)
            val embs = ArrayList<FloatArray>()
            for ((i, s) in sentences.withIndex()) {
                runOnUiThread { voiceStatus.text = "🎤 جملہ ${i + 1}/6 — اب بولیں:\n\n$s" }
                Thread.sleep(700)
                val a = Voice.record(4000)
                val e = if (a != null) Voice.embedding(a) else null
                if (e != null) embs.add(e)
            }
            val msg: String
            if (embs.size >= 4) {
                prefs.profile = Voice.Profile.build(embs).serialize()
                msg = "✓ آپ کی آواز محفوظ ہو گئی۔ اب 'ٹیسٹ' دبا کر دیکھیں"
            } else {
                msg = "✗ آواز صاف نہیں آئی۔ خاموش جگہ پر قریب سے دوبارہ کوشش کریں"
            }
            runOnUiThread {
                voiceStatus.text = msg
                if (wasRunning) startForegroundService(Intent(this, BabliService::class.java))
            }
        }.start()
    }

    private fun testVoice() {
        val prof = Voice.Profile.parse(prefs.profile)
        if (prof == null) {
            Toast.makeText(this, "پہلے آواز رجسٹر کریں", Toast.LENGTH_LONG).show()
            return
        }
        val wasRunning = BabliState.running
        stopService(Intent(this, BabliService::class.java))
        voiceStatus.text = "🎤 اب کچھ بولیں (3 سیکنڈ)..."
        val level = sens.progress + 1
        Thread {
            Thread.sleep(700)
            val a = Voice.record(3000)
            val e = if (a != null) Voice.embedding(a) else null
            val msg = if (e == null) {
                "آواز بہت کم تھی، دوبارہ کریں"
            } else {
                val d = prof.dist(e)
                val thr = prof.threshold(level)
                val ok = d <= thr
                val strict = d <= thr * 0.8f
                (if (ok) "✓ آپ کی آواز" else "✗ پہچانی نہیں") +
                    (if (ok && strict) " (لاک کھولنے کے قابل)" else if (ok) " (لاک کھولنے کے لیے کمزور)" else "") +
                    "\nسکور %.2f / حد %.2f".format(d, thr)
            }
            runOnUiThread {
                voiceStatus.text = msg
                if (wasRunning) startForegroundService(Intent(this, BabliService::class.java))
            }
        }.start()
    }
}
