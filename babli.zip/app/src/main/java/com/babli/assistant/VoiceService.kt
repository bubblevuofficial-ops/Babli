package com.babli.assistant

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.MediaStore
import android.provider.Settings
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.widget.Toast

class VoiceService : Service() {

    private val handler = Handler(Looper.getMainLooper())
    private var recognizer: SpeechRecognizer? = null
    private var running = false

    private val wakeWords = listOf(
        "ببلی", "بابلی", "ببلی", "بُبلی", "babli", "bubbly", "bubli", "babbly",
        "बबली", "बब्ली", "बाबली"
    )
    private val openWords = listOf(
        "کھولو", "کھولیں", "کھول", "کھلو", "open", "खोलो", "खोल", "کھولنا"
    )
    private val fillerWords = listOf(
        "دو", "ذرا", "ایپ", "اپ", "app", "ऐप", "ایپلیکیشن", "کو", "پلیز", "zara"
    )

    // اردو / ہندی / انگلش نام -> ایپ کے نام کا حصہ
    private val aliases = mapOf(
        "whatsapp" to listOf("واٹس ایپ", "واٹس اپ", "وٹس ایپ", "وٹس اپ", "whatsapp", "व्हाट्सएप", "व्हाट्सऐप", "वाट्सएप"),
        "youtube" to listOf("یوٹیوب", "یو ٹیوب", "youtube", "यूट्यूब"),
        "chrome" to listOf("کروم", "chrome", "क्रोम"),
        "facebook" to listOf("فیس بک", "فیسبک", "facebook", "फेसबुक"),
        "instagram" to listOf("انسٹاگرام", "انسٹا گرام", "instagram", "इंस्टाग्राम"),
        "tiktok" to listOf("ٹک ٹاک", "tiktok"),
        "gallery" to listOf("گیلری", "gallery", "गैलरी", "photos", "فوٹوز"),
        "calculator" to listOf("کیلکولیٹر", "calculator", "कैलकुलेटर"),
        "@camera" to listOf("کیمرہ", "کیمرا", "camera", "कैमरा"),
        "@settings" to listOf("سیٹنگ", "سیٹنگز", "settings", "सेटिंग", "सेटिंग्स"),
        "@dialer" to listOf("ڈائلر", "ڈائیلر", "dialer", "phone", "फोन", "ڈائل پیڈ")
    )

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val channelId = "babli"
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(channelId, "Babli", NotificationManager.IMPORTANCE_LOW)
        )
        val notif = Notification.Builder(this, channelId)
            .setContentTitle("ببلی سن رہی ہے")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1, notif, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        } else {
            startForeground(1, notif)
        }
        if (!running) {
            running = true
            listen()
        }
        return START_STICKY
    }

    override fun onDestroy() {
        running = false
        handler.removeCallbacksAndMessages(null)
        recognizer?.destroy()
        super.onDestroy()
    }

    private fun listen() {
        if (!running) return
        handler.post {
            recognizer?.destroy()
            recognizer = SpeechRecognizer.createSpeechRecognizer(this).also { r ->
                r.setRecognitionListener(object : RecognitionListener {
                    override fun onResults(results: Bundle?) {
                        val list = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        list?.forEach { if (handleSpeech(it)) return@forEach }
                        restart(300)
                    }
                    override fun onError(error: Int) { restart(700) }
                    override fun onReadyForSpeech(params: Bundle?) {}
                    override fun onBeginningOfSpeech() {}
                    override fun onRmsChanged(rmsdB: Float) {}
                    override fun onBufferReceived(buffer: ByteArray?) {}
                    override fun onEndOfSpeech() {}
                    override fun onPartialResults(partialResults: Bundle?) {}
                    override fun onEvent(eventType: Int, params: Bundle?) {}
                })
                val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ur-PK")
                i.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
                r.startListening(i)
            }
        }
    }

    private fun restart(delay: Long) {
        if (running) handler.postDelayed({ listen() }, delay)
    }

    /** true اگر ببلی کو مخاطب کیا گیا */
    private fun handleSpeech(raw: String): Boolean {
        val text = raw.trim().lowercase()
        var idx = -1
        var wakeLen = 0
        for (w in wakeWords) {
            val p = text.indexOf(w)
            if (p >= 0) { idx = p; wakeLen = w.length; break }
        }
        if (idx < 0) return false
        val command = text.substring(idx + wakeLen).trim()
        toast("سنا: $command")
        runCommand(command)
        return true
    }

    private fun runCommand(command: String) {
        val tokens = command.split(" ", "،", ",").filter { it.isNotBlank() }
        val isOpen = tokens.any { it in openWords }
        if (!isOpen) {
            toast("ابھی صرف 'کھولو' والی کمانڈ چلتی ہے")
            return
        }
        val nameTokens = tokens.filter { it !in openWords && it !in fillerWords }
        val name = nameTokens.joinToString(" ").trim()
        if (name.isEmpty()) { toast("کون سی ایپ؟"); return }

        // alias تلاش
        var key: String? = null
        for ((k, list) in aliases) {
            if (list.any { name.contains(it) }) { key = k; break }
        }
        when (key) {
            "@camera" -> launch(Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA))
            "@settings" -> launch(Intent(Settings.ACTION_SETTINGS))
            "@dialer" -> launch(Intent(Intent.ACTION_DIAL))
            else -> openAppByLabel(key ?: name)
        }
    }

    private fun openAppByLabel(query: String) {
        val pm = packageManager
        val main = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(main, 0)
        val q = query.lowercase()
        val match = apps.firstOrNull {
            it.loadLabel(pm).toString().lowercase().contains(q) ||
                it.activityInfo.packageName.lowercase().contains(q)
        }
        if (match == null) { toast("ایپ نہیں ملی: $query"); return }
        val launch = pm.getLaunchIntentForPackage(match.activityInfo.packageName)
        if (launch != null) {
            toast("کھول رہی ہوں: ${match.loadLabel(pm)}")
            launch(launch)
        }
    }

    private fun launch(i: Intent) {
        try {
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(i)
        } catch (e: Exception) {
            toast("نہیں کھل سکی: ${e.message}")
        }
    }

    private fun toast(msg: String) {
        handler.post { Toast.makeText(this, msg, Toast.LENGTH_SHORT).show() }
    }
}
