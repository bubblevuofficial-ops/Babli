package com.babli.assistant

import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.ln
import kotlin.math.log10
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.sqrt

/** آواز کی بنیادی پہچان: MFCC کی اوسط اور پھیلاؤ سے ایک "آواز کا نشان" بنتا ہے۔ */
object Voice {
    const val SR = 16000
    private const val FRAME = 400
    private const val HOP = 160
    private const val NFFT = 512
    private const val NMEL = 26
    private const val NCEP = 13

    private val window = FloatArray(FRAME) { (0.54 - 0.46 * cos(2.0 * PI * it / (FRAME - 1))).toFloat() }
    private val melBank: Array<FloatArray> by lazy { buildMel() }
    private val dct: Array<FloatArray> by lazy {
        Array(NCEP) { k -> FloatArray(NMEL) { n -> cos(PI * k * (n + 0.5) / NMEL).toFloat() } }
    }

    private fun hz2mel(h: Double) = 2595.0 * log10(1.0 + h / 700.0)
    private fun mel2hz(m: Double) = 700.0 * (10.0.pow(m / 2595.0) - 1.0)

    private fun buildMel(): Array<FloatArray> {
        val lo = hz2mel(100.0)
        val hi = hz2mel(SR / 2.0 - 200.0)
        val pts = DoubleArray(NMEL + 2) { mel2hz(lo + (hi - lo) * it / (NMEL + 1)) }
        val bins = IntArray(NMEL + 2) { floor((NFFT + 1) * pts[it] / SR).toInt() }
        return Array(NMEL) { m ->
            val f = FloatArray(NFFT / 2 + 1)
            if (bins[m + 1] > bins[m]) {
                for (k in bins[m] until bins[m + 1]) f[k] = (k - bins[m]).toFloat() / (bins[m + 1] - bins[m])
            }
            if (bins[m + 2] > bins[m + 1]) {
                for (k in bins[m + 1] until bins[m + 2]) f[k] = (bins[m + 2] - k).toFloat() / (bins[m + 2] - bins[m + 1])
            }
            f
        }
    }

    private fun fft(re: FloatArray, im: FloatArray) {
        val n = re.size
        var j = 0
        for (i in 1 until n) {
            var bit = n shr 1
            while ((j and bit) != 0) {
                j = j xor bit
                bit = bit shr 1
            }
            j = j xor bit
            if (i < j) {
                val tr = re[i]; re[i] = re[j]; re[j] = tr
                val ti = im[i]; im[i] = im[j]; im[j] = ti
            }
        }
        var len = 2
        while (len <= n) {
            val ang = -2.0 * PI / len
            val wr = cos(ang).toFloat()
            val wi = sin(ang).toFloat()
            var i = 0
            while (i < n) {
                var cr = 1f
                var ci = 0f
                val half = len / 2
                for (k in 0 until half) {
                    val ur = re[i + k]
                    val ui = im[i + k]
                    val xr = re[i + k + half] * cr - im[i + k + half] * ci
                    val xi = re[i + k + half] * ci + im[i + k + half] * cr
                    re[i + k] = ur + xr
                    im[i + k] = ui + xi
                    re[i + k + half] = ur - xr
                    im[i + k + half] = ui - xi
                    val ncr = cr * wr - ci * wi
                    ci = cr * wi + ci * wr
                    cr = ncr
                }
                i += len
            }
            len = len shl 1
        }
    }

    /** 24 اعداد کا نشان (12 اوسط + 12 پھیلاؤ) یا null اگر آواز کم ہو */
    fun embedding(s: ShortArray): FloatArray? {
        if (s.size < SR / 2) return null
        val x = FloatArray(s.size)
        x[0] = s[0] / 32768f
        for (i in 1 until s.size) x[i] = (s[i] - 0.97f * s[i - 1]) / 32768f
        val nFrames = (x.size - FRAME) / HOP + 1
        if (nFrames < 20) return null
        val feats = ArrayList<FloatArray>()
        val energies = ArrayList<Float>()
        val re = FloatArray(NFFT)
        val im = FloatArray(NFFT)
        for (f in 0 until nFrames) {
            java.util.Arrays.fill(re, 0f)
            java.util.Arrays.fill(im, 0f)
            var e = 0f
            for (i in 0 until FRAME) {
                val v = x[f * HOP + i] * window[i]
                re[i] = v
                e += v * v
            }
            fft(re, im)
            val ps = FloatArray(NFFT / 2 + 1) { re[it] * re[it] + im[it] * im[it] }
            val mel = FloatArray(NMEL)
            for (m in 0 until NMEL) {
                var sum = 0f
                val b = melBank[m]
                for (k in b.indices) if (b[k] != 0f) sum += b[k] * ps[k]
                mel[m] = ln(sum + 1e-10f)
            }
            val c = FloatArray(NCEP)
            for (k in 0 until NCEP) {
                var t = 0f
                for (n in 0 until NMEL) t += dct[k][n] * mel[n]
                c[k] = t
            }
            feats.add(c)
            energies.add(e)
        }
        val sorted = energies.sorted()
        val thr = sorted[(sorted.size * 0.4).toInt()]
        val sel = ArrayList<FloatArray>()
        for (i in feats.indices) if (energies[i] >= thr) sel.add(feats[i])
        if (sel.size < 15) return null
        val out = FloatArray(2 * (NCEP - 1))
        for (k in 1 until NCEP) {
            var m = 0f
            for (c in sel) m += c[k]
            m /= sel.size
            var v = 0f
            for (c in sel) v += (c[k] - m) * (c[k] - m)
            v /= sel.size
            out[k - 1] = m
            out[NCEP - 1 + k - 1] = sqrt(v)
        }
        return out
    }

    class Profile(val mean: FloatArray, val sigma: FloatArray, val baseline: Float) {
        fun dist(x: FloatArray): Float {
            var s = 0f
            for (i in x.indices) {
                val d = (x[i] - mean[i]) / sigma[i]
                s += d * d
            }
            return sqrt(s / x.size)
        }

        fun threshold(sensitivity: Int): Float = baseline * mult(sensitivity)

        fun serialize(): String {
            val l = ArrayList<Float>()
            for (v in mean) l.add(v)
            for (v in sigma) l.add(v)
            l.add(baseline)
            return l.joinToString(",")
        }

        companion object {
            fun parse(s: String?): Profile? {
                if (s.isNullOrEmpty()) return null
                return try {
                    val v = s.split(",").map { it.toFloat() }
                    val d = (v.size - 1) / 2
                    Profile(v.subList(0, d).toFloatArray(), v.subList(d, 2 * d).toFloatArray(), v[2 * d])
                } catch (e: Exception) {
                    null
                }
            }

            fun build(samples: List<FloatArray>): Profile {
                val d = samples[0].size
                val mean = FloatArray(d)
                for (s in samples) for (i in 0 until d) mean[i] += s[i] / samples.size
                val std = FloatArray(d)
                for (s in samples) for (i in 0 until d) std[i] += (s[i] - mean[i]) * (s[i] - mean[i]) / samples.size
                var avg = 0f
                for (i in 0 until d) {
                    std[i] = sqrt(std[i])
                    avg += std[i] / d
                }
                val sigma = FloatArray(d) { maxOf(std[it], 0.5f * avg, 0.01f) }
                val tmp = Profile(mean, sigma, 1f)
                var b = 0f
                for (s in samples) b += tmp.dist(s) / samples.size
                return Profile(mean, sigma, maxOf(b, 0.3f))
            }
        }
    }

    fun mult(sensitivity: Int): Float {
        val m = floatArrayOf(1.3f, 1.6f, 2.0f, 2.5f, 3.2f)
        return m[(sensitivity - 1).coerceIn(0, 4)]
    }

    fun record(ms: Int): ShortArray? {
        val total = SR * ms / 1000
        val minBuf = AudioRecord.getMinBufferSize(SR, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val rec = try {
            AudioRecord(
                MediaRecorder.AudioSource.VOICE_RECOGNITION, SR,
                AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, maxOf(minBuf, 32000)
            )
        } catch (e: Exception) {
            return null
        }
        if (rec.state != AudioRecord.STATE_INITIALIZED) {
            rec.release()
            return null
        }
        val out = ShortArray(total)
        var pos = 0
        rec.startRecording()
        while (pos < total) {
            val n = rec.read(out, pos, total - pos)
            if (n <= 0) break
            pos += n
        }
        rec.stop()
        rec.release()
        return if (pos >= total / 2) out.copyOf(pos) else null
    }
}
