package com.babli.assistant

import android.os.Handler
import android.os.Looper

object BabliState {
    private val main = Handler(Looper.getMainLooper())
    private val lines = ArrayList<String>()

    @Volatile var level = 0f
    @Volatile var mode = "idle"      // idle, listening, thinking, speaking
    @Volatile var running = false
    @Volatile var onLog: (() -> Unit)? = null

    @Synchronized
    fun add(s: String) {
        lines.add(s)
        if (lines.size > 60) lines.removeAt(0)
        main.post { onLog?.invoke() }
    }

    @Synchronized
    fun text(): String = lines.joinToString("\n\n")
}
