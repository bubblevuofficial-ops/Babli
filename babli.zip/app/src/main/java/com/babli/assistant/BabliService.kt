package com.babli.assistant

import android.app.KeyguardManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioRecord
import android.media.MediaRecorder
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.provider.AlarmClock
import android.provider.Settings
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.telecom.TelecomManager
import android.telephony.SmsManager
import android.view.KeyEvent
import android.view.accessibility.AccessibilityNodeInfo
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors

class BabliService : Service() {

    private lateinit var prefs: Prefs
    private val handler = Handler(Looper.getMainLooper())
    private val executor = Executors.newSingleThreadExecutor()
    private var tts: TextToSpeech? = null
    private var urOk = false
    private var cpuLock: PowerManager.WakeLock? = null

    @Volatile private var running = false
    @Volatile private var speaking = false
    @Volatile private var busy = false
    @Volatile private var mutedUntil = 0L
    @Volatile private var convoUntil = 0L

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        prefs = Prefs(this)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("babli", "Babli", NotificationManager.IMPORTANCE_LOW))
        val pi = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val notif = Notification.Builder(this, "babli")
            .setContentTitle("سیف کی ببلی سن رہی ہے")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentIntent(pi)
            .build()
        if (Build.VERSION.SDK_INT >= 30) {
            startForeground(1, notif, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        } else {
            startForeground(1, notif)
        }
        if (!running) {
            running = true
            BabliState.running = true
            BabliState.mode = "listening"
            val pm = getSystemService(PowerManager::class.java)
            cpuLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "babli:cpu")
            cpuLock?.acquire()
            initTts()
            Thread { loop() }.start()
            BabliState.add("🎙 ببلی سن رہی ہے۔ کہیں: \"ببلی ...\"")
        }
        return START_STICKY
    }

    override fun onDestroy() {
        running = false
        BabliState.running = false
        BabliState.mode = "idle"
        BabliState.level = 0f
        try { tts?.shutdown() } catch (e: Exception) {}
        try { if (cpuLock?.isHeld == true) cpuLock?.release() } catch (e: Exception) {}
        executor.shutdownNow()
        super.onDestroy()
    }

    // ---------------- آواز کی آواز (TTS) ----------------

    private fun initTts() {
        tts = TextToSpeech(this) { st ->
            val t = tts
            if (st == TextToSpeech.SUCCESS && t != null) {
                val r = t.setLanguage(Locale("ur", "PK"))
                urOk = r != TextToSpeech.LANG_MISSING_DATA && r != TextToSpeech.LANG_NOT_SUPPORTED
                if (!urOk) t.setLanguage(Locale("hi", "IN"))
                t.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) {}
                    override fun onDone(utteranceId: String?) { spokenDone() }
                    @Deprecated("Deprecated in Java")
                    override fun onError(utteranceId: String?) { spokenDone() }
                })
            }
        }
    }

    private fun spokenDone() {
        speaking = false
        mutedUntil = System.currentTimeMillis() + 600
        if (!busy) BabliState.mode = "listening"
    }

    private fun say(ur: String, hi: String = "") {
        BabliState.add("🤖 $ur")
        convoUntil = System.currentTimeMillis() + 12000
        if (!prefs.speak) return
        val t = tts ?: return
        val text = if (urOk || hi.isEmpty()) ur else hi
        speaking = true
        BabliState.mode = "speaking"
        val r = t.speak(text, TextToSpeech.QUEUE_FLUSH, null, "u" + System.nanoTime())
        if (r != TextToSpeech.SUCCESS) spokenDone()
    }

    // ---------------- مائیک اور آواز کا ٹکڑا ----------------

    private fun loop() {
        var rec: AudioRecord? = null
        try {
            val minBuf = AudioRecord.getMinBufferSize(16000, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
            rec = AudioRecord(
                MediaRecorder.AudioSource.VOICE_RECOGNITION, 16000,
                AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, maxOf(minBuf, 32000)
            )
            if (rec.state != AudioRecord.STATE_INITIALIZED) {
                BabliState.add("❌ مائیک شروع نہیں ہوا۔ اجازت چیک کریں")
                handler.post { stopSelf() }
                return
            }
            rec.startRecording()
            val frame = ShortArray(320)
            val pre = java.util.ArrayDeque<ShortArray>()
            val cur = ArrayList<ShortArray>()
            var inUtt = false
            var voicedRun = 0
            var silent = 0
            var noise = 300f
            while (running) {
                val n = rec.read(frame, 0, frame.size)
                if (n <= 0) {
                    Thread.sleep(10)
                    continue
                }
                var sum = 0.0
                for (i in 0 until n) {
                    val v = frame[i].toDouble()
                    sum += v * v
                }
                val rms = Math.sqrt(sum / n).toFloat()
                BabliState.level = BabliState.level * 0.6f + (rms / 5000f).coerceIn(0f, 1f) * 0.4f
                if (speaking || busy || System.currentTimeMillis() < mutedUntil) {
                    inUtt = false; cur.clear(); pre.clear(); voicedRun = 0; silent = 0
                    continue
                }
                val thr = maxOf(noise * 3f, 600f)
                val voice = rms > thr
                val copy = frame.copyOf(n)
                if (!inUtt) {
                    if (!voice) noise = minOf(noise * 0.98f + rms * 0.02f, 1500f)
                    pre.addLast(copy)
                    if (pre.size > 15) pre.removeFirst()
                    if (voice) voicedRun++ else voicedRun = 0
                    if (voicedRun >= 3) {
                        inUtt = true
                        cur.clear()
                        cur.addAll(pre)
                        silent = 0
                    }
                } else {
                    cur.add(copy)
                    if (voice) silent = 0 else silent++
                    if (silent >= 35 || cur.size > 450) {
                        val voicedFrames = cur.size - silent
                        inUtt = false
                        voicedRun = 0
                        pre.clear()
                        if (voicedFrames >= 22) {
                            var total = 0
                            for (f in cur) total += f.size
                            val out = ShortArray(total)
                            var pos = 0
                            for (f in cur) {
                                System.arraycopy(f, 0, out, pos, f.size)
                                pos += f.size
                            }
                            busy = true
                            BabliState.mode = "thinking"
                            executor.execute { process(out) }
                        }
                        cur.clear()
                        silent = 0
                    }
                }
            }
        } catch (e: Exception) {
            BabliState.add("❌ مائیک ایرر: ${e.message}")
        } finally {
            try { rec?.stop() } catch (e: Exception) {}
            try { rec?.release() } catch (e: Exception) {}
        }
    }

    // ---------------- پروسیسنگ ----------------

    private fun process(s: ShortArray) {
        try {
            var strict = false
            val prof = Voice.Profile.parse(prefs.profile)
            if (prof != null) {
                val e = Voice.embedding(s)
                if (e == null) return
                val d = prof.dist(e)
                val thr = prof.threshold(prefs.sensitivity)
                if (d > thr) {
                    BabliState.add("🔇 دوسری آواز نظر انداز (%.1f > %.1f)".format(d, thr))
                    return
                }
                strict = d <= thr * 0.8f
            }
            if (prefs.apiKey.isEmpty()) {
                BabliState.add("⚠️ سیٹنگز میں Gemini key ڈالیں")
                return
            }
            val raw = Gemini.call(prefs.apiKey, prefs.model, prompt(), wav(s))
            val j = parse(raw) ?: return
            if (!j.optBoolean("wake", false)) return
            val heard = j.optString("heard", "")
            if (heard.isNotEmpty()) BabliState.add("🗣 $heard")
            val ur = j.optString("reply_ur", "")
            val hi = j.optString("reply_hi", "")
            if (ur.isNotEmpty()) say(ur, hi)
            val acts = j.optJSONArray("actions") ?: JSONArray()
            runActions(acts, strict, prof != null)
        } catch (e: Exception) {
            BabliState.add("❌ ${e.message}")
        } finally {
            busy = false
            if (!speaking) BabliState.mode = "listening"
        }
    }

    private fun parse(raw: String): JSONObject? {
        val t = raw.trim().removePrefix("```json").removePrefix("```").removeSuffix("```").trim()
        return try {
            if (t.startsWith("[")) JSONArray(t).getJSONObject(0) else JSONObject(t)
        } catch (e: Exception) {
            null
        }
    }

    private fun wav(s: ShortArray): ByteArray {
        val total = s.size * 2
        val h = ByteBuffer.allocate(44).order(ByteOrder.LITTLE_ENDIAN)
        h.put("RIFF".toByteArray()); h.putInt(36 + total)
        h.put("WAVE".toByteArray()); h.put("fmt ".toByteArray())
        h.putInt(16); h.putShort(1.toShort()); h.putShort(1.toShort())
        h.putInt(16000); h.putInt(32000); h.putShort(2.toShort()); h.putShort(16.toShort())
        h.put("data".toByteArray()); h.putInt(total)
        val d = ByteBuffer.allocate(total).order(ByteOrder.LITTLE_ENDIAN)
        for (v in s) d.putShort(v)
        val bos = ByteArrayOutputStream()
        bos.write(h.array())
        bos.write(d.array())
        return bos.toByteArray()
    }

    private fun prompt(): String {
        val name = prefs.userName
        val apps = Apps.list(this).take(160).joinToString(", ") { it.label }
        val now = SimpleDateFormat("EEEE d MMMM yyyy, HH:mm", Locale.ENGLISH).format(Date())
        val convo = System.currentTimeMillis() < convoUntil
        return """
You are Babli (ببلی), the personal voice assistant of $name, living inside his Android phone. You hear one short audio clip. The speaker mixes Urdu, Hindi and English.
conversation_active=$convo
Wake word: "Babli" (ببلی / बबली / bubbly / bubli). If conversation_active is false and the clip does not call Babli, or it is only noise or unclear, answer exactly {"wake":false}
If conversation_active is true the user may continue without the wake word.
Otherwise understand what the user wants and answer with ONE JSON object only:
{"wake":true,"heard":"what was said, in Urdu script","reply_ur":"short warm reply in Urdu script, call him $name","reply_hi":"the same reply in Devanagari script","actions":[]}
Each action is an object {"type":...} with params. Types:
open_app{app} (app must be exactly one label from the installed list), call{to}, hangup, answer_call, sms{to,text}, whatsapp{to,text} (send a WhatsApp message), whatsapp_chat{to} (only open the chat), youtube{query} (search and play), web{query}, scroll{dir:up|down|left|right}, tap{text} (tap on-screen text), type{text}, back, home, recents, notifications, lock, unlock, screenshot, flashlight{on:true|false}, wifi{on}, bluetooth{on}, volume{mode:up|down|max|mute}, media{mode:play_pause|next|prev}, alarm{hour,minute}, timer{seconds}, wait{ms}.
For "to" write the contact name in English letters, or digits if a number was spoken.
Chain several actions in order for multi-step requests. If it is only a question or chat, answer briefly in reply_ur and reply_hi and use "actions":[]. Never invent other action types.
Current time: $now
Installed apps: $apps
""".trimIndent()
    }

    // ---------------- کام کرنا ----------------

    private val uiTypes = setOf(
        "open_app", "call", "whatsapp", "whatsapp_chat", "youtube", "web", "scroll", "tap", "type",
        "back", "home", "recents", "notifications", "screenshot", "wifi", "bluetooth"
    )

    private fun runActions(arr: JSONArray, strict: Boolean, hasProfile: Boolean) {
        var needUi = false
        for (i in 0 until arr.length()) {
            val t = arr.optJSONObject(i)?.optString("type", "") ?: ""
            if (t in uiTypes || t == "unlock") needUi = true
        }
        if (needUi) {
            if (!ensureUnlocked(strict, hasProfile)) return
        }
        for (i in 0 until arr.length()) {
            val a = arr.optJSONObject(i) ?: continue
            try {
                act(a)
            } catch (e: Exception) {
                BabliState.add("⚠️ ${a.optString("type")}: ${e.message}")
            }
        }
    }

    @Suppress("DEPRECATION")
    private fun wakeScreen() {
        val pm = getSystemService(PowerManager::class.java)
        val wl = pm.newWakeLock(
            PowerManager.FULL_WAKE_LOCK or PowerManager.ACQUIRE_CAUSES_WAKEUP or PowerManager.ON_AFTER_RELEASE,
            "babli:wake"
        )
        wl.acquire(6000)
    }

    private fun ensureUnlocked(strict: Boolean, hasProfile: Boolean): Boolean {
        val km = getSystemService(KeyguardManager::class.java)
        val pm = getSystemService(PowerManager::class.java)
        if (!pm.isInteractive) {
            wakeScreen()
            Thread.sleep(700)
        }
        if (!km.isKeyguardLocked) return true
        if (!hasProfile) {
            say("پہلے سیٹنگز میں اپنی آواز رجسٹر کریں، پھر میں لاک کھول سکوں گی")
            return false
        }
        if (!strict) {
            say("آواز پوری طرح نہیں پہچانی، ذرا قریب سے دوبارہ بولیں")
            return false
        }
        val pin = prefs.loadPin()
        if (pin == null) {
            say("سیٹنگز میں پن محفوظ نہیں ہے")
            return false
        }
        val acc = BabliAccess.inst
        if (acc == null) {
            say("Accessibility چالو نہیں ہے")
            return false
        }
        acc.unlockWithPin(pin)
        Thread.sleep(900)
        if (km.isKeyguardLocked) {
            BabliState.add("⚠️ لاک نہیں کھلا۔ پن کیپیڈ نہیں ملا یا پن غلط ہے")
            return false
        }
        return true
    }

    private fun launch(i: Intent) {
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        val c: Context = BabliAccess.inst ?: this
        c.startActivity(i)
    }

    private fun waNumber(raw: String): String {
        var d = raw.filter { it.isDigit() }
        if (raw.trim().startsWith("+")) return d
        if (d.startsWith("00")) return d.substring(2)
        if (d.startsWith("0")) d = prefs.countryCode + d.substring(1)
        return d
    }

    private fun waIntent(url: String): Intent {
        val i = Intent(Intent.ACTION_VIEW, Uri.parse(url))
        val pm = packageManager
        val pkg = listOf("com.whatsapp", "com.whatsapp.w4b").firstOrNull {
            try { pm.getPackageInfo(it, 0); true } catch (e: Exception) { false }
        }
        if (pkg != null) i.setPackage(pkg)
        return i
    }

    private fun act(a: JSONObject) {
        val acc = BabliAccess.inst
        when (a.optString("type")) {
            "open_app" -> {
                val app = Apps.find(this, a.optString("app"))
                val li = if (app != null) packageManager.getLaunchIntentForPackage(app.pkg) else null
                if (li != null) launch(li) else say("ایپ نہیں ملی: ${a.optString("app")}")
            }
            "call" -> {
                val c = Apps.contact(this, a.optString("to"))
                if (c == null) {
                    say("کانٹیکٹ نہیں ملا")
                } else {
                    BabliState.add("📞 ${c.first}")
                    launch(Intent(Intent.ACTION_CALL, Uri.parse("tel:" + Uri.encode(c.second))))
                }
            }
            "hangup" -> {
                val tm = getSystemService(TelecomManager::class.java)
                tm.endCall()
            }
            "answer_call" -> {
                val tm = getSystemService(TelecomManager::class.java)
                tm.acceptRingingCall()
            }
            "sms" -> {
                val c = Apps.contact(this, a.optString("to"))
                if (c == null) {
                    say("کانٹیکٹ نہیں ملا")
                } else {
                    val sm = getSystemService(SmsManager::class.java)
                    val parts = sm.divideMessage(a.optString("text"))
                    sm.sendMultipartTextMessage(c.second, null, parts, null, null)
                    BabliState.add("✉️ SMS بھیجا: ${c.first}")
                }
            }
            "whatsapp", "whatsapp_chat" -> {
                val c = Apps.contact(this, a.optString("to"))
                if (c == null) {
                    say("کانٹیکٹ نہیں ملا")
                } else {
                    val send = a.optString("type") == "whatsapp"
                    var url = "https://wa.me/" + waNumber(c.second)
                    if (send) url += "?text=" + Uri.encode(a.optString("text"))
                    launch(waIntent(url))
                    if (send && acc != null) {
                        Thread.sleep(3500)
                        for (k in 0 until 8) {
                            if (acc.clickId("com.whatsapp:id/send") || acc.clickId("com.whatsapp.w4b:id/send") || acc.clickText("Send")) break
                            Thread.sleep(700)
                        }
                    }
                }
            }
            "youtube" -> {
                val q = a.optString("query")
                val i = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/results?search_query=" + Uri.encode(q)))
                try {
                    packageManager.getPackageInfo("com.google.android.youtube", 0)
                    i.setPackage("com.google.android.youtube")
                } catch (e: Exception) {
                }
                launch(i)
                if (acc != null) {
                    Thread.sleep(4500)
                    acc.playFirstVideo()
                }
            }
            "web" -> launch(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + Uri.encode(a.optString("query")))))
            "scroll" -> acc?.scroll(a.optString("dir", "down"))
            "tap" -> if (acc?.clickText(a.optString("text")) != true) say("اسکرین پر نہیں ملا: ${a.optString("text")}")
            "type" -> acc?.typeText(a.optString("text"))
            "back" -> acc?.global(android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_BACK)
            "home" -> acc?.global(android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_HOME)
            "recents" -> acc?.global(android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_RECENTS)
            "notifications" -> acc?.global(android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_NOTIFICATIONS)
            "lock" -> acc?.global(android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_LOCK_SCREEN)
            "screenshot" -> acc?.global(android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_TAKE_SCREENSHOT)
            "unlock" -> {}
            "flashlight" -> {
                val cm = getSystemService(CameraManager::class.java)
                for (id in cm.cameraIdList) {
                    val ok = cm.getCameraCharacteristics(id).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
                    if (ok) {
                        cm.setTorchMode(id, a.optBoolean("on", true))
                        break
                    }
                }
            }
            "wifi" -> {
                launch(Intent(Settings.Panel.ACTION_WIFI))
                Thread.sleep(1800)
                acc?.setSwitch(a.optBoolean("on", true))
                Thread.sleep(600)
                acc?.global(android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_BACK)
            }
            "bluetooth" -> {
                launch(Intent(Settings.ACTION_BLUETOOTH_SETTINGS))
                Thread.sleep(1800)
                acc?.setSwitch(a.optBoolean("on", true))
                Thread.sleep(600)
                acc?.global(android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_BACK)
            }
            "volume" -> {
                val am = getSystemService(AudioManager::class.java)
                when (a.optString("mode")) {
                    "up" -> am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI)
                    "down" -> am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI)
                    "max" -> am.setStreamVolume(AudioManager.STREAM_MUSIC, am.getStreamMaxVolume(AudioManager.STREAM_MUSIC), AudioManager.FLAG_SHOW_UI)
                    "mute" -> am.setStreamVolume(AudioManager.STREAM_MUSIC, 0, AudioManager.FLAG_SHOW_UI)
                }
            }
            "media" -> {
                val am = getSystemService(AudioManager::class.java)
                val code = when (a.optString("mode")) {
                    "next" -> KeyEvent.KEYCODE_MEDIA_NEXT
                    "prev" -> KeyEvent.KEYCODE_MEDIA_PREVIOUS
                    else -> KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE
                }
                am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, code))
                am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, code))
            }
            "alarm" -> {
                val i = Intent(AlarmClock.ACTION_SET_ALARM)
                    .putExtra(AlarmClock.EXTRA_HOUR, a.optInt("hour"))
                    .putExtra(AlarmClock.EXTRA_MINUTES, a.optInt("minute"))
                    .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
                launch(i)
            }
            "timer" -> {
                val i = Intent(AlarmClock.ACTION_SET_TIMER)
                    .putExtra(AlarmClock.EXTRA_LENGTH, a.optInt("seconds", 60))
                    .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
                launch(i)
            }
            "wait" -> Thread.sleep(a.optLong("ms", 1000).coerceIn(0L, 10000L))
        }
    }
}
