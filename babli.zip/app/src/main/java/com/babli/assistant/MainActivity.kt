package com.babli.assistant

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class MainActivity : Activity() {
    private lateinit var log: TextView
    private lateinit var scroll: ScrollView
    private lateinit var status: TextView
    private lateinit var toggle: Button
    private val h = Handler(Looper.getMainLooper())
    private val tick = object : Runnable {
        override fun run() {
            val m = when (BabliState.mode) {
                "listening" -> "👂 سن رہی ہوں"
                "thinking" -> "🧠 سوچ رہی ہوں"
                "speaking" -> "🗣 بول رہی ہوں"
                else -> "💤 بند ہے"
            }
            status.text = m
            toggle.text = if (BabliState.running) "ببلی بند کریں" else "ببلی شروع کریں"
            h.postDelayed(this, 400)
        }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val bg = Color.parseColor("#05060F")
        window.statusBarColor = bg
        window.navigationBarColor = bg

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(bg)
        root.setPadding(dp(16), dp(24), dp(16), dp(16))

        val logo = ImageView(this)
        logo.setImageResource(R.drawable.logo)
        val lp = LinearLayout.LayoutParams(dp(96), dp(96))
        lp.gravity = Gravity.CENTER_HORIZONTAL
        root.addView(logo, lp)

        val title = TextView(this)
        title.text = "سیف کی ببلی"
        title.setTextColor(Color.WHITE)
        title.textSize = 22f
        title.typeface = Typeface.DEFAULT_BOLD
        title.gravity = Gravity.CENTER
        root.addView(title, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        root.addView(OrbView(this), LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        status = TextView(this)
        status.setTextColor(Color.parseColor("#90CAF9"))
        status.textSize = 16f
        status.gravity = Gravity.CENTER
        root.addView(status, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        log = TextView(this)
        log.setTextColor(Color.parseColor("#CFD8DC"))
        log.textSize = 14f
        log.setPadding(dp(10), dp(8), dp(10), dp(8))
        scroll = ScrollView(this)
        scroll.setBackgroundColor(Color.parseColor("#0B1020"))
        scroll.addView(log)
        val sp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(170))
        sp.topMargin = dp(8)
        root.addView(scroll, sp)

        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        toggle = Button(this)
        toggle.setOnClickListener {
            if (BabliState.running) {
                stopService(Intent(this, BabliService::class.java))
            } else if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                BabliState.add("⚠️ پہلے سیٹنگز میں جا کر اجازتیں دیں")
                startActivity(Intent(this, SettingsActivity::class.java))
            } else {
                startForegroundService(Intent(this, BabliService::class.java))
            }
        }
        val set = Button(this)
        set.text = "⚙️ سیٹنگز"
        set.setOnClickListener { startActivity(Intent(this, SettingsActivity::class.java)) }
        val bl = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        row.addView(toggle, bl)
        row.addView(set, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        root.addView(row, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        setContentView(root)
    }

    override fun onResume() {
        super.onResume()
        BabliState.onLog = {
            log.text = BabliState.text()
            scroll.post { scroll.fullScroll(android.view.View.FOCUS_DOWN) }
        }
        log.text = BabliState.text()
        h.post(tick)
    }

    override fun onPause() {
        super.onPause()
        BabliState.onLog = null
        h.removeCallbacks(tick)
    }
}
